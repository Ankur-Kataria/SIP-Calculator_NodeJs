$(function () {
	$.ajax({
		url: "http://127.0.0.1:3000/get",
	}).done(function (response) {
		$('#SIP_amount').val(response.PerMonthAmt);
		$('#SIP_amount_value').text(formatNumber(response.PerMonthAmt));

		$('#Investment_Period_Input').val(response.noOfYear);
		$('#Investment_Period_value').text(response.noOfYear + " Year(s)");

		$('#NoOfPerc_Index_Input').val(response.returnPercentage);
		$('#NoOfPerc_Index_value').text(response.returnPercentage + "%");

		$('#InvestedAmt').text(response.invAmt);
		$('#sipReturnAmnt').text(response.calValue);
		//console.log(response);
	}).fail(function (message) {
		console.log(message);
	});


	//---FUNCTION TO FORMAT AMOUNT / NUMBER
	function formatNumber(number, hasDecimal) {
		if (hasDecimal) {
			var decimal = number.toString().split(".");
			var x = decimal[0];
			var decimal_point = "." + decimal[1];
		} else {
			var x = number;
			var decimal_point = '';
		}
		x = x.toString();
		var lastThree = x.substring(x.length - 3);
		var otherNumbers = x.substring(0, x.length - 3);
		if (otherNumbers != '')
			lastThree = ',' + lastThree;
		var res = "Rs. " + otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + lastThree + decimal_point;
		return (res);
	}

	//---SIP AMOUNT JQUERY SLIDER 
	$("#SIP_amount_Slider").slider({
		range: "min",
		value: 500,
		min: 500,
		max: 500000,
		step: 500,
		slide: function (event, ui) {
			$('#SIP_amount_value').text(formatNumber(ui.value));
			$("#SIP_amount").val(ui.value);
			showResult();
		}
	});

	//---INVESTMENT PERIOD JQUERY SLIDER  
	$("#Investment_Period_Slider").slider({
		range: "min",
		value: 1,
		min: 1,
		max: 50,
		step: 1,
		slide: function (event, ui) {
			$('#Investment_Period_value').text(ui.value + " Year(s)");
			$("#Investment_Period_Input").val(ui.value);
			showResult();
		}
	});

	//---NO of percentage INDEX JQUERY SLIDER 
	$("#NoOfPerc_Index_Slider").slider({
		range: "min",
		value: 1,
		min: 1,
		max: 30,
		step: 1,
		slide: function (event, ui) {
			$('#NoOfPerc_Index_value').text(ui.value + "%");
			$("#NoOfPerc_Index_Input").val(ui.value);
			showResult();
		}
	});

	$("#SIP_amount, #Investment_Period_Input, #NoOfPerc_Index_Input").blur(function (e) {
		var obj_val = parseFloat($(this).val());
		var min_val = parseFloat($(this).data("min"));
		var max_val = parseFloat($(this).data("max"));

		if (obj_val <= 0 || isNaN(obj_val) || obj_val < min_val) {
			$(this).val(min_val);
			obj_val = min_val;
		}
		else if (obj_val > max_val) {
			$(this).val(max_val);
			obj_val = max_val;
		}

		if ($(this).context.name == "SIP_amount") {
			$('#SIP_amount_value').text(formatNumber(obj_val));
		} else if ($(this).context.name == "Investment_Period_Input") {
			$('#Investment_Period_value').text(obj_val + " Year(s)");
		} else if ($(this).context.name == "NoOfPerc_Index_Input") {
			$('#NoOfPerc_Index_value').text(obj_val + "%");
		}

		showResult();
	});

	function showResult() {
		try {
			var PerMonthAmt = $('#SIP_amount').val();
			var noOfYear = $('#Investment_Period_Input').val()
			var returnPercentage = $('#NoOfPerc_Index_Input').val();

			$.ajax({
				type: "POST",
				url: "http://127.0.0.1:3000/post",
				dataType: 'json',
				data: { 'PerMonthAmt': PerMonthAmt, 'noOfYear': noOfYear, 'returnPercentage': returnPercentage },
			}).done(function (response) {
				$('#InvestedAmt').text(response.invAmt);
				$('#sipReturnAmnt').text(response.calValue);
				//console.log(response);
			}).fail(function (message) {
				console.log(message);
			});

		} catch (execption) {
			console.log(execption);
		}
	}

});