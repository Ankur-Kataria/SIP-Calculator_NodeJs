var express = require('express');
var app = express();
var http = require('http').Server(app);
const bodyParser = require("body-parser");
const cors = require("cors");

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(cors());

app.get('/', function (req, res) {
  res.send('Hello World!')
});

app.get('/get', function (req, res) {

  var sipData = {
    'PerMonthAmt': 3000,
    'noOfYear': 1,
    'returnPercentage': 8
  }
  var result = sipInvestGet(sipData);
  res.send(Object.assign({},result,sipData));
});

app.post('/post', function (req, res) {
  var response = (req.body);
  var result = sipInvestGet(response);
  res.send(result);
});

function sipInvestGet(response) {
  var res;
  var Total_Investment = response['PerMonthAmt'];
  var Tenure = response['noOfYear'];
  var rateOfIntrest = response['returnPercentage'];
  A = 12 * Tenure;
  B = parseFloat(rateOfIntrest / 12);

  var tnrInv = Tenure * 12;

  var invAmt = dispNum(Total_Investment * tnrInv);
  futureValue = parseFloat(-SIPCalculator(rateOfIntrest, A, Total_Investment));
  calValue = dispNum(futureValue);
  return res = { 'invAmt': invAmt, 'calValue': calValue };
}

function SIPCalculator(returnspercent, nper, PMT) {
  try {
    var fv;
    var e9 = PMT;
    var e10 = (returnspercent) / 12;
    e10 = (e10 / 100);
    var e11 = nper;
    var frm1 = (1 + e10);
    var frm2 = Math.pow(frm1, e11);
    var frm3 = (frm2 - 1);
    var frm4 = (frm3 / e10);
    var frm5 = e9 * frm4;
    fv = frm5 * (-1);
    return fv.toFixed(0);
  } catch (error) {
    console.log(error.message);
  }

}

function dispNum(n) {
  var nStr = Math.round(n);
  nStr += '';
  x = nStr.split('.');
  x1 = x[0];
  x2 = x.length > 1 ? '.' + x[1] : '';
  var rgx = /(\d+)(\d{3})/;
  var z = 0;
  var len = String(x1).length;
  var num = parseInt((len / 2) - 1);

  while (rgx.test(x1)) {
    if (z > 0) {
      x1 = x1.replace(rgx, '$1' + ',' + '$2');
    } else {
      x1 = x1.replace(rgx, '$1' + ',' + '$2');
      rgx = /(\d+)(\d{2})/;
    }
    z++;
    num--;
    if (num == 0) {
      break;
    }
  }
  return x1 + x2;
}

var server = http.listen(3000, () => {
  console.log('server is running on port', server.address().port);
});
